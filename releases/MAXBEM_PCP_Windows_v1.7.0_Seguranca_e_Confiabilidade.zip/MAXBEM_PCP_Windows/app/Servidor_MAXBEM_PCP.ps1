﻿param([ValidateRange(1024,65535)][int]$Port=48721,[string]$DataDirectory=(Join-Path $PSScriptRoot 'data'))
# Windows PowerShell 5.1 or newer; loopback only, no administrator required.
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0
$Database=Join-Path $DataDirectory 'maxbem_pcp_database.json'
$Backup="$Database.bak"
$LogFile=Join-Path $DataDirectory 'server.log'
$Utf8=New-Object System.Text.UTF8Encoding($false,$true)
$Schema=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'schema.json')) | ConvertFrom-Json
$Authority="127.0.0.1:$Port"
$BaseUrl="http://$Authority"
$MaxBody=5*1024*1024
$Random=[Security.Cryptography.RandomNumberGenerator]::Create()
$TokenBytes=New-Object byte[] 32
$Random.GetBytes($TokenBytes)
$Token=[Convert]::ToBase64String($TokenBytes)
$Random.Dispose()
[IO.Directory]::CreateDirectory($DataDirectory) | Out-Null
function Write-Log([string]$Message) {
    try {
        if ((Test-Path $LogFile) -and (Get-Item $LogFile).Length -gt 1048576) { Move-Item -LiteralPath $LogFile -Destination "$LogFile.1" -Force }
        [IO.File]::AppendAllText($LogFile,"$(Get-Date -Format o) $Message`n",$Utf8)
    } catch { Write-Warning 'Nao foi possivel gravar o log local.' }
}
function Reject([int]$Status,[string]$Message) {
    $Exception=New-Object System.Exception($Message)
    $Exception.Data['Status']=$Status
    throw $Exception
}
function Valid-Date([string]$Value,[string]$Format) {
    $Parsed=[DateTime]::MinValue
    return [DateTime]::TryParseExact($Value,$Format,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$Parsed) -and $Parsed.Year -ge 1900
}
function Validate-Database($Data) {
    if ($null -eq $Data -or $Data -isnot [pscustomobject]) { Reject 422 'Banco deve ser um objeto JSON.' }
    $Names=@($Schema.PSObject.Properties.Name)
    foreach ($P in $Data.PSObject.Properties) { if ($Names -cnotcontains $P.Name) { Reject 422 'Campo desconhecido no banco.' } }
    $Sets=@{}; $Total=0
    foreach ($Name in $Names) {
        $P=$Data.PSObject.Properties[$Name]
        if ($null -eq $P -and $Name -eq 'schedules') { $Data | Add-Member -NotePropertyName schedules -NotePropertyValue @(); $P=$Data.PSObject.Properties[$Name] }
        if ($null -eq $P -or $P.Value -isnot [Array]) { Reject 422 'Lista ausente ou invalida.' }
        $Rows=$P.Value; $Total+=$Rows.Count
        if ($Rows.Count -gt 10000 -or $Total -gt 30000) { Reject 422 'Limite de registros excedido.' }
        $Fields=$Schema.PSObject.Properties[$Name].Value
        $FieldNames=@($Fields.PSObject.Properties.Name)
        $Ids=@{}; $Codes=@{}
        foreach ($Row in $Rows) {
            if ($null -eq $Row -or $Row -isnot [pscustomobject]) { Reject 422 'Registro invalido.' }
            foreach ($P in $Row.PSObject.Properties) { if ($FieldNames -cnotcontains $P.Name) { Reject 422 'Campo desconhecido no registro.' } }
            foreach ($F in $Fields.PSObject.Properties) {
                $Rule=$F.Value; $P=$Row.PSObject.Properties[$F.Name]
                $Value=if ($null -eq $P) { $null } else { $P.Value }
                # PowerShell 7 converts ISO JSON timestamps to DateTime during parsing.
                # Canonicalize them; Windows PowerShell 5.1 keeps the original strings.
                if ($Rule.type -eq 'timestamp' -and $Value -is [DateTime]) {
                    $Value=$Value.ToUniversalTime().ToString("yyyy-MM-dd'T'HH:mm:ss.fff'Z'",[Globalization.CultureInfo]::InvariantCulture)
                    $P.Value=$Value
                }
                if ($null -eq $Value -and $null -ne $Rule.PSObject.Properties['nullable'] -and $Rule.nullable) { continue }
                if ($null -eq $Value -and $null -ne $Rule.PSObject.Properties['optional'] -and $Rule.optional) { continue }
                if ($Rule.type -eq 'number') {
                    if ($null -eq $Value -or $Value -is [bool] -or $Value -is [Array] -or $Value -is [pscustomobject]) { Reject 422 'Numero invalido.' }
                    if ($Value -is [string] -and $Value -cnotmatch '^-?\d+(\.\d+)?$') { Reject 422 'Numero invalido.' }
                    $Number=0.0
                    if (-not [double]::TryParse([string]$Value,[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$Number)) { Reject 422 'Numero invalido.' }
                    if ([double]::IsNaN($Number) -or [double]::IsInfinity($Number) -or $Number -lt $Rule.min -or $Number -gt $Rule.max) { Reject 422 'Numero fora do intervalo.' }
                    if ($null -ne $Rule.PSObject.Properties['integer'] -and $Rule.integer -and [Math]::Floor($Number) -ne $Number) { Reject 422 'Identificador invalido.' }
                } else {
                    if ($Value -isnot [string]) { Reject 422 ("Texto invalido: "+$Name+'.'+$F.Name) }
                    switch ($Rule.type) {
                        'text' {
                            $Optional=$null -ne $Rule.PSObject.Properties['optional'] -and $Rule.optional
                            if ((-not $Optional -and -not $Value.Trim()) -or $Value.Trim().Length -gt $Rule.max -or $Value -match '[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]') { Reject 422 ("Texto invalido: "+$Name+'.'+$F.Name) }
                        }
                        'enum' { if ($Rule.values -cnotcontains $Value) { Reject 422 'Opcao invalida.' } }
                        'date' { if ($Value -cnotmatch '^\d{4}-\d{2}-\d{2}$' -or -not (Valid-Date $Value 'yyyy-MM-dd')) { Reject 422 'Data invalida.' } }
                        'month' { if ($Value -cnotmatch '^\d{4}-\d{2}$' -or -not (Valid-Date "$Value-01" 'yyyy-MM-dd')) { Reject 422 'Mes invalido.' } }
                        'timestamp' { if ($Value -cnotmatch '^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$' -or -not (Valid-Date $Value "yyyy-MM-dd'T'HH:mm:ss.fff'Z'")) { Reject 422 'Data e hora invalidas.' } }
                    }
                }
            }
            $Key=([double]$Row.id).ToString('0',[Globalization.CultureInfo]::InvariantCulture)
            if ($Ids.ContainsKey($Key)) { Reject 422 'Identificador duplicado.' }; $Ids[$Key]=$true
            if (@('products','orders','stock') -contains $Name) {
                $Code=if ($Name -eq 'products') { $Row.sku.Trim() } else { $Row.code.Trim() }
                if ($Codes.ContainsKey($Code)) { Reject 422 'Codigo duplicado.' }; $Codes[$Code]=$true
            }
        }
        $Sets[$Name]=$Ids
    }
    foreach ($Name in @('plans','schedules','orders')) {
        foreach ($Row in $Data.PSObject.Properties[$Name].Value) {
            if (-not $Sets.products.ContainsKey(([double]$Row.productId).ToString('0',[Globalization.CultureInfo]::InvariantCulture))) { Reject 422 'Produto inexistente.' }
        }
    }
    foreach ($Row in $Data.schedules) { if ($null -ne $Row.planId -and -not $Sets.plans.ContainsKey(([double]$Row.planId).ToString('0',[Globalization.CultureInfo]::InvariantCulture))) { Reject 422 'Plano inexistente.' } }
    foreach ($Row in $Data.logs) { if (-not $Sets.orders.ContainsKey(([double]$Row.orderId).ToString('0',[Globalization.CultureInfo]::InvariantCulture))) { Reject 422 'Ordem inexistente.' } }
    foreach ($Row in $Data.moves) { if (-not $Sets.stock.ContainsKey(([double]$Row.itemId).ToString('0',[Globalization.CultureInfo]::InvariantCulture))) { Reject 422 'Item inexistente.' } }
}
function Database-Bytes {
    if (-not (Test-Path -LiteralPath $Database)) { return ,([byte[]]@()) }
    if ((Get-Item -LiteralPath $Database).Length -gt $MaxBody) { Reject 503 'Banco excede o limite. Preserve os arquivos para recuperacao.' }
    $Bytes=[IO.File]::ReadAllBytes($Database)
    try { $Data=$Utf8.GetString($Bytes) | ConvertFrom-Json; Validate-Database $Data }
    catch { Reject 503 'Banco invalido. Preserve o original e o arquivo .bak para recuperacao.' }
    return ,$Bytes
}
function Version([byte[]]$Bytes) {
    if (-not $Bytes.Length) { return '"0"' }
    $Hasher=[Security.Cryptography.SHA256]::Create()
    try { return '"'+([BitConverter]::ToString($Hasher.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant()+'"' }
    finally { $Hasher.Dispose() }
}
function Send-Response($Stream,[int]$Status,[string]$Type,[byte[]]$Body,[string]$ETag='') {
    $Texts=@{200='OK';204='No Content';400='Bad Request';403='Forbidden';404='Not Found';405='Method Not Allowed';408='Request Timeout';409='Conflict';411='Length Required';413='Payload Too Large';415='Unsupported Media Type';422='Unprocessable Entity';431='Request Header Fields Too Large';500='Internal Server Error';503='Service Unavailable'}
    $Header="HTTP/1.1 $Status $($Texts[$Status])`r`nContent-Type: $Type`r`nContent-Length: $($Body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`nX-Content-Type-Options: nosniff`r`nX-Frame-Options: DENY`r`nReferrer-Policy: no-referrer`r`nCross-Origin-Resource-Policy: same-origin`r`nPermissions-Policy: camera=(), microphone=(), geolocation=()`r`nContent-Security-Policy: default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self'; connect-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'; form-action 'self'`r`n"
    if ($ETag) { $Header+="ETag: $ETag`r`n" }; $Header+="`r`n"
    $HeaderBytes=[Text.Encoding]::ASCII.GetBytes($Header)
    $Stream.Write($HeaderBytes,0,$HeaderBytes.Length)
    if ($Body.Length) { $Stream.Write($Body,0,$Body.Length) }
}
function Read-Request($Stream) {
    $Bytes=New-Object 'System.Collections.Generic.List[byte]'; $Tail=''
    $Deadline=[DateTime]::UtcNow.AddSeconds(10)
    do {
        $Remaining=[int]($Deadline-[DateTime]::UtcNow).TotalMilliseconds
        if ($Remaining -le 0) { Reject 408 'Tempo de requisicao esgotado.' }
        $Stream.ReadTimeout=[Math]::Min(5000,[Math]::Max(1,$Remaining))
        try { $Value=$Stream.ReadByte() } catch { Reject 408 'Leitura interrompida ou tempo esgotado.' }
        if ($Value -lt 0) { Reject 400 'Cabecalho incompleto.' }
        $Bytes.Add([byte]$Value)
        if ($Bytes.Count -gt 16384) { Reject 431 'Cabecalho muito grande.' }
        $Tail+=[char]$Value; if ($Tail.Length -gt 4) { $Tail=$Tail.Substring($Tail.Length-4) }
    } while ($Tail -cne "`r`n`r`n")
    $Lines=[Text.Encoding]::ASCII.GetString($Bytes.ToArray()) -split "`r`n"
    if ($Lines[0] -cnotmatch '^(GET|POST) (/[^\s]*) HTTP/1\.[01]$') { Reject 405 'Metodo ou destino nao permitido.' }
    $Method=$Matches[1]; $Path=$Matches[2]; $Headers=@{}
    foreach ($Line in $Lines[1..($Lines.Length-1)]) {
        if (-not $Line) { continue }
        if ($Line -notmatch '^([A-Za-z0-9-]+):[ \t]*([^\r\n]*)$') { Reject 400 'Cabecalho invalido.' }
        $Key=$Matches[1].ToLowerInvariant(); $Value=$Matches[2].Trim()
        if ($Headers.ContainsKey($Key)) { Reject 400 'Cabecalho duplicado.' }; $Headers[$Key]=$Value
    }
    if ($Headers['host'] -cne $Authority) { Reject 403 'Host nao autorizado.' }
    if ($Headers.ContainsKey('origin') -and $Headers['origin'] -cne $BaseUrl) { Reject 403 'Origem nao autorizada.' }
    if ($Headers.ContainsKey('sec-fetch-site') -and @('same-origin','none') -cnotcontains $Headers['sec-fetch-site']) { Reject 403 'Requisicao externa bloqueada.' }
    if ($Headers.ContainsKey('transfer-encoding') -or $Headers.ContainsKey('expect')) { Reject 400 'Codificacao nao suportada.' }
    $Length=0L
    if ($Headers.ContainsKey('content-length')) {
        if ($Headers['content-length'] -cnotmatch '^\d{1,10}$') { Reject 400 'Tamanho invalido.' }; $Length=[long]$Headers['content-length']
    }
    if ($Length -gt $MaxBody) { Reject 413 'Arquivo excede 5 MiB.' }
    if ($Method -eq 'GET' -and $Length -ne 0) { Reject 400 'GET nao aceita corpo.' }
    if ($Path.StartsWith('/api/') -and $Path -cne '/api/health' -and $Headers['x-maxbem-request'] -cne '1') { Reject 403 'Cabecalho de seguranca ausente.' }
    if ($Method -eq 'POST') {
        if ($Path -cne '/api/db') { Reject 405 'Gravacao nao permitida.' }
        if ($Headers['x-maxbem-token'] -cne $Token) { Reject 403 'Sessao invalida.' }
        if (-not $Headers.ContainsKey('content-length')) { Reject 411 'Informe o tamanho.' }
        if ($Headers['content-type'] -notmatch '^application/json(\s*;\s*charset=utf-8)?$') { Reject 415 'Envie JSON UTF-8.' }
        if (-not $Headers.ContainsKey('if-match')) { Reject 409 'Versao do banco ausente.' }
    }
    $Body=New-Object byte[] ([int]$Length); $Offset=0
    while ($Offset -lt $Length) {
        $Remaining=[int]($Deadline-[DateTime]::UtcNow).TotalMilliseconds
        if ($Remaining -le 0) { Reject 408 'Tempo de requisicao esgotado.' }
        $Stream.ReadTimeout=[Math]::Min(5000,[Math]::Max(1,$Remaining))
        try { $Read=$Stream.Read($Body,$Offset,([int]$Length-$Offset)) } catch { Reject 408 'Leitura interrompida ou tempo esgotado.' }
        if ($Read -le 0) { Reject 400 'Corpo incompleto; banco preservado.' }; $Offset+=$Read
    }
    return @{Method=$Method;Path=$Path;Headers=$Headers;Body=$Body}
}
try {
    $DataLock=[IO.File]::Open((Join-Path $DataDirectory '.server.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $Listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,$Port); $Listener.Start(32)
}
catch { Write-Log 'Porta ocupada; servidor nao iniciado.'; Write-Error 'Porta ocupada. Nao abra o aplicativo em um servidor desconhecido.'; exit 1 }
Write-Log 'Servidor 1.7.0 iniciado em loopback.'
try {
    while ($true) {
        $Client=$Listener.AcceptTcpClient(); $Stream=$null
        try {
            $Client.ReceiveTimeout=5000; $Client.SendTimeout=5000; $Stream=$Client.GetStream()
            $Request=Read-Request $Stream; $Path=$Request.Path
            if ($Request.Method -eq 'POST') {
                $Current=Database-Bytes
                if ($Request.Headers['if-match'] -cne (Version $Current)) { Reject 409 'Banco alterado em outra janela. Exporte as alteracoes e recarregue.' }
                try { $Data=$Utf8.GetString($Request.Body) | ConvertFrom-Json } catch { Reject 422 'JSON invalido; banco preservado.' }
                Validate-Database $Data
                $NewBytes=$Utf8.GetBytes(($Data | ConvertTo-Json -Depth 10 -Compress))
                if ($NewBytes.Length -gt $MaxBody) { Reject 413 'Banco excede 5 MiB.' }
                $Temp=Join-Path $DataDirectory ([IO.Path]::GetRandomFileName())
                try {
                    $File=[IO.File]::Open($Temp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
                    try { $File.Write($NewBytes,0,$NewBytes.Length); $File.Flush($true) } finally { $File.Dispose() }
                    if (Test-Path -LiteralPath $Database) { [IO.File]::Replace($Temp,$Database,$Backup,$true) }
                    else { [IO.File]::Move($Temp,$Database) }
                } finally { if (Test-Path -LiteralPath $Temp) { Remove-Item -LiteralPath $Temp -Force } }
                Send-Response $Stream 204 'application/json; charset=utf-8' ([byte[]]@()) (Version $NewBytes)
            } elseif ($Path -ceq '/api/db') {
                $Bytes=Database-Bytes
                if ($Bytes.Length) { Send-Response $Stream 200 'application/json; charset=utf-8' $Bytes (Version $Bytes) }
                else { Send-Response $Stream 404 'application/json; charset=utf-8' ($Utf8.GetBytes('{}')) '"0"' }
            } elseif ($Path -ceq '/api/session') {
                Send-Response $Stream 200 'application/json; charset=utf-8' ($Utf8.GetBytes((@{token=$Token} | ConvertTo-Json -Compress)))
            } elseif ($Path -ceq '/api/health') {
                $null=Database-Bytes
                Send-Response $Stream 200 'application/json; charset=utf-8' ($Utf8.GetBytes('{"app":"MAXBEM-PCP","version":"1.7.0","protocol":2}'))
            } else {
                $Routes=@{'/'=@('index.html','text/html; charset=utf-8');'/index.html'=@('index.html','text/html; charset=utf-8');'/app.js'=@('app.js','text/javascript; charset=utf-8');'/business.js'=@('business.js','text/javascript; charset=utf-8');'/schema.js'=@('schema.js','text/javascript; charset=utf-8');'/styles.css'=@('styles.css','text/css; charset=utf-8');'/maxbem_logo.png'=@('maxbem_logo.png','image/png');'/favicon.ico'=@('maxbem_m.ico','image/x-icon')}
                if (-not $Routes.ContainsKey($Path) -or $Path -cmatch '[A-Z]') { Reject 404 'Nao encontrado.' }
                $Route=$Routes[$Path]; Send-Response $Stream 200 $Route[1] ([IO.File]::ReadAllBytes((Join-Path $PSScriptRoot $Route[0])))
            }
        } catch {
            $Status=if ($_.Exception.Data.Contains('Status')) { [int]$_.Exception.Data['Status'] } elseif ($_.Exception -is [IO.IOException]) { 408 } else { 500 }
            $Message=if ($_.Exception.Data.Contains('Status')) { $_.Exception.Message } elseif ($Status -eq 408) { 'Tempo de requisicao esgotado.' } else { 'Falha interna. Banco preservado; consulte o log local.' }
            Write-Log "Requisicao recusada ou falhou: HTTP $Status."
            if ($null -ne $Stream) { try { Send-Response $Stream $Status 'application/json; charset=utf-8' ($Utf8.GetBytes((@{error=$Message} | ConvertTo-Json -Compress))) } catch { } }
        } finally { $Client.Close() }
    }
} finally { $Listener.Stop(); $DataLock.Dispose() }
