@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0Iniciar_MAXBEM_PCP.ps1"
if errorlevel 1 (
  echo Nao foi possivel iniciar o MAXBEM PCP. Consulte a mensagem acima.
  pause
  exit /b 1
)
exit /b 0
