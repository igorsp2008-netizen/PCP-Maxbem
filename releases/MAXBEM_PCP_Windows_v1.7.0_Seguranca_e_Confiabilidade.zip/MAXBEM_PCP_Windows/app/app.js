const seed = {
  products: [
    {
      id: 1,
      sku: "MEL-VID-285",
      name: "Mel Vidro 285 g",
      unit: "caixas",
      capacity: 100,
      safety: 50,
    },
    {
      id: 2,
      sku: "MEL-VID-544",
      name: "Mel Vidro 544 g",
      unit: "caixas",
      capacity: 85,
      safety: 40,
    },
    {
      id: 3,
      sku: "MEL-PET-350",
      name: "Mel PET 350 g",
      unit: "caixas",
      capacity: 110,
      safety: 60,
    },
    {
      id: 4,
      sku: "MEL-PET-700",
      name: "Mel PET 700 g",
      unit: "caixas",
      capacity: 80,
      safety: 40,
    },
    {
      id: 5,
      sku: "MEL-BIS-500",
      name: "Mel Bisnaga 500 g",
      unit: "caixas",
      capacity: 95,
      safety: 50,
    },
  ],
  plans: [],
  schedules: [],
  orders: [],
  logs: [],
  stock: [
    {
      id: 1,
      code: "MP-MEL",
      name: "Mel a granel",
      unit: "kg",
      minimum: 5000,
      balance: 0,
    },
    {
      id: 2,
      code: "EMB-TAMPA",
      name: "Tampa",
      unit: "un",
      minimum: 2500,
      balance: 0,
    },
  ],
  moves: [],
};
let state,
  view = "dashboard",
  scheduleMonth = new Date().toISOString().slice(0, 7);
const $ = (s) => document.querySelector(s),
  fmt = (n) =>
    Number(n || 0).toLocaleString("pt-BR", { maximumFractionDigits: 1 });
let dbVersion = null,
  sessionToken = null,
  committed = null,
  saving = false,
  recovery = null,
  statusMessage = "";
const MAX_FILE = 5 * 1024 * 1024;
async function request(path, options = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  try {
    return await fetch(path, {
      ...options,
      cache: "no-store",
      signal: controller.signal,
      headers: { "X-MAXBEM-Request": "1", ...options.headers },
    });
  } finally {
    clearTimeout(timeout);
  }
}
async function getSession() {
  const response = await request("/api/session");
  if (!response.ok)
    throw new Error(
      "Não foi possível abrir uma sessão segura com o banco local.",
    );
  const data = await response.json();
  if (typeof data.token !== "string" || data.token.length !== 44)
    throw new Error("Servidor local incompatível.");
  sessionToken = data.token;
}
async function load() {
  await getSession();
  const response = await request("/api/db");
  if (response.status !== 404 && !response.ok)
    throw new Error(
      "Não foi possível ler o banco. Preserve o arquivo original e o .bak; nenhum dado foi substituído.",
    );
  dbVersion = response.headers.get("ETag");
  if (!dbVersion)
    throw new Error(
      "Servidor desatualizado ou incompatível. Reinicie o aplicativo.",
    );
  state = PCPData.validate(
    response.status === 404 ? structuredClone(seed) : await response.json(),
  );
  committed = structuredClone(state);
  statusMessage =
    response.status === 404
      ? "Banco novo: os exemplos serão gravados apenas ao salvar a primeira alteração."
      : "";
}
async function persist(candidate) {
  const body = JSON.stringify(candidate);
  if (new Blob([body]).size > MAX_FILE)
    throw new Error("O banco excede o limite de 5 MiB.");
  const options = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-MAXBEM-Token": sessionToken,
      "If-Match": dbVersion,
    },
    body,
  };
  let response = await request("/api/db", options);
  if (response.status === 403) {
    await getSession();
    options.headers["X-MAXBEM-Token"] = sessionToken;
    response = await request("/api/db", options);
  }
  if (!response.ok) {
    if (response.status === 409)
      throw new Error(
        "Outra janela alterou o banco. Exporte as alterações pendentes e recarregue antes de editar novamente.",
      );
    let message = "Não foi possível salvar. O banco não foi confirmado.";
    try {
      message = (await response.json()).error || message;
    } catch {}
    throw new Error(message);
  }
  const version = response.headers.get("ETag");
  if (!version)
    throw new Error(
      "Gravação sem confirmação de versão. Exporte as alterações pendentes e recarregue.",
    );
  dbVersion = version;
}
async function save() {
  if (saving) throw new Error("Aguarde a gravação atual.");
  const candidate = structuredClone(state);
  saving = true;
  try {
    const clean = PCPData.validate(candidate);
    await persist(clean);
    state = clean;
    committed = structuredClone(clean);
    recovery = null;
    statusMessage = "Dados salvos e confirmados no banco local.";
    render();
  } catch (error) {
    state = structuredClone(committed);
    recovery = candidate;
    statusMessage =
      error.name === "AbortError"
        ? "A gravação não foi confirmada a tempo. Exporte as alterações pendentes e recarregue."
        : error.message;
    render();
    throw new Error(statusMessage);
  } finally {
    saving = false;
  }
}
function newId() {
  return Math.max(
    Date.now(),
    ...Object.values(state).flatMap((rows) => rows.map((row) => row.id + 1)),
  );
}
function safeHTML(html) {
  return Object.freeze({ html });
}
function statusNotice() {
  return statusMessage
    ? `<div class="notice" role="status" aria-live="polite">${xml(statusMessage)} ${recovery ? '<button data-action="exportRecovery">Exportar alterações pendentes</button> <button data-action="reload">Recarregar banco</button>' : ""}</div>`
    : "";
}
const menus = [
  ["dashboard", "▦ Visão geral"],
  ["products", "▤ Produtos"],
  ["planning", "◫ Planejamento mensal"],
  ["schedule", "▦ Programação diária"],
  ["orders", "✓ Ordens de produção"],
  ["logs", "◉ Apontamentos"],
  ["stock", "▥ Estoque"],
  ["reports", "↗ Relatórios"],
  ["settings", "⚙ Configurações"],
];
async function init() {
  try {
    await load();
  } catch (error) {
    $("#app").innerHTML =
      '<div class="notice" role="alert"><h1>Banco indisponível</h1><p>' +
      xml(error.message) +
      '</p><p>Feche o aplicativo e consulte LEIA-ME.txt para recuperação. O banco não foi sobrescrito.</p><button data-action="reload">Tentar novamente</button></div>';
    return;
  }
  $("#nav").innerHTML = menus
    .map(([k, l]) => `<button data-v="${k}">${l}</button>`)
    .join("");
  $("#nav").onclick = (e) => {
    if (e.target.dataset.v) {
      view = e.target.dataset.v;
      render();
    }
  };
  render();
}
function head(t, s, b = "") {
  let now = new Date().toLocaleString("pt-BR");
  return `<header><div><h1>${t}</h1><p>${s}</p></div><div class="header-actions"><span class="db-pill">Banco: Local confirmado</span><span class="admin-pill">Uso local</span><span class="date-pill">${now}</span>${b}</div></header>`;
}
function product(id) {
  return (
    state.products.find((x) => x.id == id) || {
      sku: "-",
      name: "Produto removido",
    }
  );
}
function metrics() {
  let planned = state.orders.reduce((a, x) => a + Number(x.qty), 0),
    produced = state.logs.reduce((a, x) => a + Number(x.good), 0),
    scrap = state.logs.reduce((a, x) => a + Number(x.scrap), 0),
    ph = state.logs.reduce((a, x) => a + Number(x.ph), 0),
    ah = state.logs.reduce((a, x) => a + Number(x.ah), 0);
  return {
    planned,
    produced,
    scrap,
    adh: planned ? (produced / planned) * 100 : 0,
    eff: ah ? (ph / ah) * 100 : 0,
    open: state.orders.filter(
      (x) => !["Concluída", "Cancelada"].includes(x.status),
    ).length,
  };
}
function render() {
  document
    .querySelectorAll("nav button")
    .forEach((b) => b.classList.toggle("on", b.dataset.v === view));
  const f = pages[view] || pages.dashboard;
  $("#app").innerHTML = statusNotice() + f();
  if (view === "dashboard") setTimeout(drawDashboardCharts, 0);
}
const pages = {
  dashboard() {
    let d = metrics(),
      statuses = ["Planejada", "Liberada", "Em produção", "Concluída"],
      counts = statuses.map(
        (s) => state.orders.filter((o) => o.status === s).length,
      ),
      max = Math.max(...counts, 1);
    return (
      head(
        "Dashboard",
        "Sistema de Planejamento, Programação e Controle da Produção • visão executiva",
      ) +
      `<div class="notice"><b>Gestão visual do PCP:</b> acompanhe volume, aderência, eficiência, perdas, ordens e estoques em uma única tela.</div><div class="cards">${[
        ["PLANEJADO", d.planned],
        ["PRODUZIDO", d.produced],
        ["ADERÊNCIA", d.adh.toFixed(1) + "%"],
        ["EFICIÊNCIA", d.eff.toFixed(1) + "%"],
        ["PERDAS", d.scrap],
        ["OPS ABERTAS", d.open],
      ]
        .map(
          (x) =>
            `<div class="card"><strong>${typeof x[1] === "string" ? xml(x[1]) : fmt(x[1])}</strong><small>${x[0]}</small></div>`,
        )
        .join(
          "",
        )}</div><div class="dashboard-grid"><div class="panel chart-card"><h3>Planejado x realizado</h3><div class="chart-sub">Comparação do volume total programado e produzido</div><div class="chart-wrap"><canvas id="planChart"></canvas></div></div><div class="panel chart-card"><h3>Aderência ao plano</h3><div class="chart-sub">Percentual produzido sobre o programado</div><div class="chart-wrap"><canvas id="adherenceGauge"></canvas><div class="chart-center"><strong>${d.adh.toFixed(1)}%</strong><span>ADERÊNCIA</span></div></div></div><div class="panel chart-card"><h3>Eficiência operacional</h3><div class="chart-sub">Horas previstas versus horas realizadas</div><div class="chart-wrap"><canvas id="efficiencyGauge"></canvas><div class="chart-center"><strong>${d.eff.toFixed(1)}%</strong><span>EFICIÊNCIA</span></div></div></div></div><div class="dashboard-grid second"><div class="panel chart-card"><h3>Tendência de produção</h3><div class="chart-sub">Produção boa e perdas por data de apontamento</div><div class="chart-wrap"><canvas id="trendChart"></canvas></div><div class="legend"><span><i style="background:#D9AE16"></i>Produção boa</span><span><i style="background:#B93838"></i>Perdas</span></div></div><div class="panel chart-card"><h3>Situação das ordens</h3><div class="chart-sub">Distribuição da carteira por status</div><div class="mini-status">${statuses.map((s, i) => `<div class="status-row"><span>${s}</span><div class="status-track"><div class="status-fill" style="width:${(counts[i] / max) * 100}%"></div></div><b>${counts[i]}</b></div>`).join("")}</div><hr style="border:0;border-top:1px solid #EAD99A;margin:22px 0"><h3>Estoque crítico</h3><p class="danger"><b>${state.stock.filter((x) => x.balance < x.minimum).length} itens</b> abaixo do nível mínimo.</p><p style="color:var(--muted);font-size:12px">Revise os itens críticos antes de liberar novas ordens.</p></div></div>`
    );
  },
  products() {
    return (
      head(
        "Produtos e SKUs",
        "Cadastro mestre de produtos",
        `<button class="primary" data-action="productForm">+ Novo produto</button>`,
      ) +
      table(
        ["SKU", "Produto", "Unidade", "Capacidade/h", "Segurança", ""],
        state.products.map((x) => [
          x.sku,
          x.name,
          x.unit,
          fmt(x.capacity),
          fmt(x.safety),
          safeHTML(
            `<button data-action="productForm" data-id="${x.id}">Editar</button>`,
          ),
        ]),
      )
    );
  },
  planning() {
    return (
      head(
        "Planejamento mensal",
        "Previsão, conversão em caixas e necessidade líquida",
        `<div class="toolbar"><button class="primary" data-action="planningPrintForm">Imprimir planejamento</button><button class="primary" data-action="planForm">+ Inserir plano</button></div>`,
      ) +
      `<div class="notice"><b>Conversão:</b> cada caixa corresponde a 12 unidades. O resultado é arredondado para baixo. <b>Necessidade:</b> previsão convertida + pedidos firmes + segurança − estoque inicial, na unidade do produto. Para produtos em kg, a previsão também é em kg. <b>Distribuição diária:</b> clique em Distribuir para programar o mês por dias de produção.</div>` +
      table(
        [
          "Mês",
          "SKU",
          "Produto",
          "Unidade",
          "Previsão (un/kg)",
          "Caixas (12 un)",
          "Pedidos",
          "Estoque",
          "Necessidade",
          "Ações",
        ],
        state.plans.map((x) => {
          let p = product(x.productId),
            need = planNeed(x);
          return [
            x.month,
            p.sku,
            p.name,
            p.unit,
            fmt(x.forecast),
            safeHTML(
              `<b>${xml(typeof planBoxes(x) === "number" ? fmt(planBoxes(x)) : planBoxes(x))}</b>`,
            ),
            fmt(x.orders),
            fmt(x.stock),
            safeHTML(`<b>${fmt(need)}</b>`),
            safeHTML(
              `<div class="toolbar"><button data-action="planForm" data-id="${x.id}">Editar</button><button class="primary" data-action="distributeForm" data-id="${x.id}">Distribuir</button></div>`,
            ),
          ];
        }),
      )
    );
  },
  schedule() {
    let rows = state.schedules
        .filter((x) => (x.date || "").startsWith(scheduleMonth))
        .sort(
          (a, b) =>
            a.date.localeCompare(b.date) ||
            product(a.productId).sku.localeCompare(product(b.productId).sku),
        ),
      total = rows.reduce((a, x) => a + (+x.qty || 0), 0);
    return (
      head(
        "Programação diária",
        "Distribuição do plano mensal por dia de produção",
        `<div class="toolbar"><input type="month" value="${scheduleMonth}" data-change="month"><button class="primary" data-action="scheduleForm">+ Programação manual</button><button class="primary" data-action="printSchedule">Imprimir programação</button></div>`,
      ) +
      `<div class="cards" style="margin-bottom:16px"><div class="card"><strong>${rows.length}</strong><small>PROGRAMAÇÕES NO MÊS</small></div><div class="card"><strong>${fmt(total)}</strong><small>VOLUME PROGRAMADO</small></div><div class="card"><strong>${new Set(rows.map((x) => x.productId)).size}</strong><small>SKUS PROGRAMADOS</small></div></div>` +
      table(
        [
          "Data",
          "Dia",
          "SKU",
          "Produto",
          "Quantidade",
          "Linha",
          "Turno",
          "Status",
          "Observações",
          "Ações",
        ],
        rows.map((x) => [
          formatDate(x.date),
          weekday(x.date),
          product(x.productId).sku,
          product(x.productId).name,
          safeHTML(`<b>${fmt(x.qty)}</b>`),
          x.line,
          x.shift,
          safeHTML(`<span class="tag">${xml(x.status)}</span>`),
          x.notes || "-",
          safeHTML(
            `<button data-action="scheduleForm" data-id="${x.id}">Editar</button>`,
          ),
        ]),
      )
    );
  },
  orders() {
    return (
      head(
        "Ordens de produção",
        "Programação por data, linha e turno",
        `<button class="primary" data-action="orderForm">+ Nova ordem</button>`,
      ) +
      table(
        [
          "OP",
          "Data",
          "Produto",
          "Quantidade",
          "Linha",
          "Turno",
          "Prioridade",
          "Status",
          "Ações",
        ],
        state.orders.map((x) => [
          x.code,
          x.date,
          product(x.productId).name,
          fmt(x.qty),
          x.line,
          x.shift,
          x.priority,
          safeHTML(`<span class="tag">${xml(x.status)}</span>`),
          safeHTML(
            `<button data-action="orderForm" data-id="${x.id}">Editar</button>`,
          ),
        ]),
      )
    );
  },
  logs() {
    return (
      head(
        "Apontamentos",
        "Produção boa, perdas, horas e paradas",
        `<button class="primary" data-action="logForm">+ Novo apontamento</button>`,
      ) +
      table(
        [
          "Data",
          "OP",
          "Produção boa",
          "Perdas",
          "Horas previstas",
          "Horas reais",
          "Parada",
          "Motivo",
          "Ações",
        ],
        state.logs.map((x) => [
          x.date,
          state.orders.find((o) => o.id == x.orderId)?.code || "-",
          fmt(x.good),
          fmt(x.scrap),
          fmt(x.ph),
          fmt(x.ah),
          fmt(x.stop) + " min",
          x.reason || "-",
          safeHTML(
            `<button data-action="logForm" data-id="${x.id}">Editar</button>`,
          ),
        ]),
      )
    );
  },
  stock() {
    return (
      head(
        "Estoque",
        "Saldos locais e níveis mínimos",
        `<div class="toolbar"><button class="primary" data-action="stockItemForm">+ Item</button><button class="primary" data-action="moveForm">Movimentar</button></div>`,
      ) +
      table(
        ["Código", "Item", "Unidade", "Saldo", "Mínimo", "Situação", "Ações"],
        state.stock.map((x) => [
          x.code,
          x.name,
          x.unit,
          fmt(x.balance),
          fmt(x.minimum),
          safeHTML(
            x.balance < x.minimum
              ? '<b class="danger">CRÍTICO</b>'
              : '<span class="tag">OK</span>',
          ),
          safeHTML(
            `<button data-action="stockItemForm" data-id="${x.id}">Editar</button>`,
          ),
        ]),
      )
    );
  },
  reports() {
    return (
      head("Relatórios", "Exporte o banco ou tabelas para análise") +
      `<div class="panel"><div class="notice">Os dados ficam neste computador. Faça backup regularmente.</div><button class="primary" data-action="exportExcel">Exportar tudo para Excel</button> <button class="primary" data-action="backup">Exportar backup completo</button> <button class="primary" data-action="csv" data-key="orders">Ordens em CSV</button> <button class="primary" data-action="csv" data-key="logs">Apontamentos em CSV</button></div>`
    );
  },
  settings() {
    return (
      head("Configurações", "Banco local e segurança dos dados") +
      `<div class="panel"><h3>Armazenamento local</h3><p>Os dados são mantidos no banco local deste computador e não são enviados à internet.</p><button class="primary" data-action="backup">Exportar backup</button> <label class="primary" style="display:inline-block;cursor:pointer">Restaurar backup<input type="file" accept=".json" hidden data-change="restore"></label> <button data-action="resetAll">Restaurar dados iniciais</button></div>`
    );
  },
};
function table(h, rows) {
  return `<table><thead><tr>${h.map((x) => `<th>${xml(x)}</th>`).join("")}</tr></thead><tbody>${rows.length ? rows.map((r) => `<tr>${r.map((x) => `<td>${x && typeof x === "object" && Object.hasOwn(x, "html") ? x.html : xml(x)}</td>`).join("")}</tr>`).join("") : `<tr><td colspan="${h.length}" class="empty">Nenhum registro cadastrado</td></tr>`}</tbody></table>`;
}
function openForm(title, fields, onSave, values = {}) {
  if (saving) return;
  $("#dlgTitle").textContent = title;
  $("#form").innerHTML = fields
    .map((f) => {
      const name = xml(f[0]);
      const type = f[2] || "text";
      const optional = ["notes", "reason", "reference"].includes(f[0]);
      const control =
        type === "select"
          ? `<select name="${name}" required>${f[3].map((o) => `<option value="${xml(o[0])}" ${String(values[f[0]]) === String(o[0]) ? "selected" : ""}>${xml(o[1])}</option>`).join("")}</select>`
          : `<input name="${name}" type="${xml(type)}" value="${xml(values[f[0]] ?? "")}" ${optional ? "" : "required"} ${type === "number" ? 'min="0" max="1000000000000" step="any"' : ""} maxlength="500">`;
      return `<label>${xml(f[1])}${control}</label>`;
    })
    .join("");
  const submit = async (e) => {
    e.preventDefault();
    if (saving || !$("#form").reportValidity()) return;
    if (recovery) {
      alert(
        "Exporte as alterações pendentes e recarregue o banco antes de editar novamente.",
      );
      return;
    }
    const button = $("#save");
    button.disabled = true;
    try {
      const values = Object.fromEntries(new FormData($("#form")));
      const result = await onSave(values);
      if (result !== false) $("#dlg").close();
    } catch (error) {
      alert(error.message);
    } finally {
      button.disabled = false;
    }
  };
  $("#save").onclick = submit;
  $("#form").onsubmit = submit;
  $("#dlg").showModal();
}
const prodOpts = () =>
  state.products.map((x) => [x.id, `${x.sku} — ${x.name}`]);
const orderOpts = () => state.orders.map((x) => [x.id, x.code]);
function productForm(id) {
  let x = state.products.find((x) => x.id == id) || {};
  openForm(
    id ? "Editar produto" : "Novo produto",
    [
      ["sku", "SKU"],
      ["name", "Nome"],
      [
        "unit",
        "Unidade",
        "select",
        [
          ["caixas", "Caixas"],
          ["unidades", "Unidades"],
          ["kg", "kg"],
        ],
      ],
      ["capacity", "Capacidade/h", "number"],
      ["safety", "Segurança (unidade do produto)", "number"],
    ],
    (v) => {
      if (id) Object.assign(x, v);
      else state.products.push({ ...v, id: newId() });
      return save();
    },
    x,
  );
}
function planForm(id) {
  let x = state.plans.find((x) => x.id == id),
    values = x || { month: new Date().toISOString().slice(0, 7) };
  openForm(
    id ? "Editar planejamento" : "Plano mensal",
    [
      ["productId", "Produto", "select", prodOpts()],
      ["month", "Mês", "month"],
      ["forecast", "Previsão (unidades; kg para produto em kg)", "number"],
      ["orders", "Pedidos firmes (unidade do produto)", "number"],
      ["stock", "Estoque inicial (unidade do produto)", "number"],
    ],
    (v) => {
      if (id) Object.assign(x, v);
      else state.plans.push({ ...v, id: newId() });
      return save();
    },
    values,
  );
}
function boxes(qty) {
  return PCPCalc.boxes(qty);
}
function planBoxes(x) {
  return product(x.productId).unit === "kg" ? "-" : boxes(x.forecast);
}
function planNeed(x) {
  return PCPCalc.need(x, product(x.productId));
}
function formatDate(v) {
  if (!v) return "-";
  let [y, m, d] = v.split("-");
  return `${d}/${m}/${y}`;
}
function weekday(v) {
  return ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"][
    new Date(v + "T12:00:00").getDay()
  ];
}
function changeScheduleMonth(v) {
  scheduleMonth = v || new Date().toISOString().slice(0, 7);
  render();
}
function distributeForm(id) {
  let x = state.plans.find((x) => x.id == id);
  if (!x) return;
  openForm(
    "Distribuir plano no mês",
    [
      [
        "calendar",
        "Dias de produção",
        "select",
        [
          ["weekdays", "Segunda a sexta"],
          ["saturday", "Segunda a sábado"],
          ["all", "Todos os dias"],
        ],
      ],
      [
        "line",
        "Linha",
        "select",
        [
          ["Linha 1", "Linha 1"],
          ["Linha 2", "Linha 2"],
        ],
      ],
      [
        "shift",
        "Turno",
        "select",
        [
          ["Comercial", "Comercial"],
          ["1º turno", "1º turno"],
          ["2º turno", "2º turno"],
        ],
      ],
      [
        "status",
        "Status inicial",
        "select",
        [
          ["Programada", "Programada"],
          ["Liberada", "Liberada"],
        ],
      ],
    ],
    (v) => {
      let existing = state.schedules.filter((s) => s.planId == id);
      if (
        existing.length &&
        !confirm(
          `Já existem ${existing.length} programações deste plano. Deseja substituí-las?`,
        )
      )
        return false;
      let [y, m] = x.month.split("-").map(Number),
        last = new Date(y, m, 0).getDate(),
        days = [];
      for (let d = 1; d <= last; d++) {
        let date = new Date(y, m - 1, d, 12),
          w = date.getDay(),
          ok =
            v.calendar === "all" ||
            (v.calendar === "saturday" && w !== 0) ||
            (v.calendar === "weekdays" && w >= 1 && w <= 5);
        if (ok)
          days.push(
            `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`,
          );
      }
      if (!days.length)
        return alert("Nenhum dia disponível para distribuição.");
      state.schedules = state.schedules.filter((s) => s.planId != id);
      let quantities = PCPCalc.distribute(
        planNeed(x),
        days.length,
        product(x.productId).unit,
      );
      let firstId = newId();
      days.forEach((date, i) =>
        state.schedules.push({
          id: firstId + i,
          planId: x.id,
          productId: x.productId,
          date,
          qty: quantities[i],
          line: v.line,
          shift: v.shift,
          status: v.status,
          notes: "",
        }),
      );
      scheduleMonth = x.month;
      view = "schedule";
      return save();
    },
    {
      calendar: "weekdays",
      line: "Linha 1",
      shift: "Comercial",
      status: "Programada",
    },
  );
}
function scheduleForm(id) {
  let x = state.schedules.find((x) => x.id == id),
    values = x || {
      date: `${scheduleMonth}-01`,
      line: "Linha 1",
      shift: "Comercial",
      status: "Programada",
    };
  openForm(
    id ? "Editar programação diária" : "Programação diária",
    [
      ["productId", "Produto", "select", prodOpts()],
      ["date", "Data", "date"],
      ["qty", "Quantidade", "number"],
      [
        "line",
        "Linha",
        "select",
        [
          ["Linha 1", "Linha 1"],
          ["Linha 2", "Linha 2"],
        ],
      ],
      [
        "shift",
        "Turno",
        "select",
        [
          ["Comercial", "Comercial"],
          ["1º turno", "1º turno"],
          ["2º turno", "2º turno"],
        ],
      ],
      [
        "status",
        "Status",
        "select",
        [
          ["Programada", "Programada"],
          ["Liberada", "Liberada"],
          ["Em produção", "Em produção"],
          ["Concluída", "Concluída"],
        ],
      ],
      ["notes", "Observações"],
    ],
    (v) => {
      if (id) Object.assign(x, v);
      else state.schedules.push({ ...v, id: newId(), planId: null });
      scheduleMonth = v.date.slice(0, 7);
      return save();
    },
    values,
  );
}
function printSchedule() {
  let rows = state.schedules
      .filter((x) => (x.date || "").startsWith(scheduleMonth))
      .sort((a, b) => a.date.localeCompare(b.date)),
    label = new Date(scheduleMonth + "-01T12:00:00").toLocaleDateString(
      "pt-BR",
      { month: "long", year: "numeric" },
    ),
    logo = document.querySelector(".brand img").src,
    w = window.open("", "_blank");
  if (!w) return alert("Permita a abertura de janelas para imprimir.");
  let body = rows
    .map(
      (x) =>
        `<tr><td>${formatDate(x.date)}</td><td>${weekday(x.date)}</td><td>${xml(product(x.productId).sku)}</td><td>${xml(product(x.productId).name)}</td><td class="num">${fmt(x.qty)}</td><td>${xml(x.line)}</td><td>${xml(x.shift)}</td><td>${xml(x.status)}</td><td>${xml(x.notes || "")}</td></tr>`,
    )
    .join("");
  w.document.write(
    `<!doctype html><html><head><meta charset="utf-8"><title>Programação ${xml(label)}</title><style>@page{size:A4 landscape;margin:12mm}body{font-family:Arial,sans-serif;color:#111;margin:0}.head{display:flex;justify-content:space-between;align-items:center;border-bottom:4px solid #D9AE16;padding-bottom:10px;margin-bottom:14px}.head img{width:180px;max-height:70px;object-fit:contain;background:#050505;padding:8px}.head h1{font-size:22px;margin:0}.head p{margin:5px 0 0;color:#555}.summary{display:flex;gap:30px;margin:10px 0 15px;font-size:12px}table{width:100%;border-collapse:collapse;font-size:9px}th{background:#050505;color:#F0CB3D;padding:7px;text-align:left}td{padding:6px;border:1px solid #bbb}.num{text-align:right;font-weight:bold}.sign{display:flex;justify-content:space-around;margin-top:35px}.sign div{width:28%;border-top:1px solid #333;text-align:center;padding-top:5px;font-size:10px}.footer{margin-top:10px;font-size:9px;color:#666;text-align:right}</style></head><body><div class="head"><img src="${logo}"><div><h1>PROGRAMAÇÃO DIÁRIA DE PRODUÇÃO</h1><p>${xml(label.toUpperCase())}</p></div></div><div class="summary"><b>Total programado: ${fmt(rows.reduce((a, x) => a + (+x.qty || 0), 0))}</b><b>Registros: ${rows.length}</b><b>Emissão: ${new Date().toLocaleString("pt-BR")}</b></div><table><thead><tr><th>Data</th><th>Dia</th><th>SKU</th><th>Produto</th><th>Qtd.</th><th>Linha</th><th>Turno</th><th>Status</th><th>Observações</th></tr></thead><tbody>${body || '<tr><td colspan="9">Nenhuma programação no período.</td></tr>'}</tbody></table><div class="sign"><div>Elaborado por</div><div>PCP</div><div>Produção</div></div><div class="footer">MAXBEM PCP • Programação controlada pelo banco local</div></body></html>`,
  );
  w.document.close();
  w.onload = () => {
    w.opener = null;
    setTimeout(() => w.print(), 300);
  };
}
function planningPrintForm() {
  let months = [...new Set(state.plans.map((x) => x.month).filter(Boolean))]
    .sort()
    .reverse();
  if (!months.length)
    return alert("Cadastre um planejamento mensal antes de imprimir.");
  openForm(
    "Imprimir planejamento mensal",
    [
      [
        "month",
        "Mês",
        "select",
        months.map((x) => [
          x,
          new Date(x + "-01T12:00:00").toLocaleDateString("pt-BR", {
            month: "long",
            year: "numeric",
          }),
        ]),
      ],
    ],
    (v) => printMonthlyPlan(v.month),
    { month: months[0] },
  );
}
function printMonthlyPlan(month) {
  let rows = state.plans
      .filter((x) => x.month === month)
      .sort((a, b) =>
        product(a.productId).sku.localeCompare(product(b.productId).sku),
      ),
    label = new Date(month + "-01T12:00:00").toLocaleDateString("pt-BR", {
      month: "long",
      year: "numeric",
    }),
    logo = document.querySelector(".brand img").src,
    w = window.open("", "_blank");
  if (!w) return alert("Permita a abertura de janelas para imprimir.");
  let totals = rows.reduce(
      (a, x) => {
        a.forecast += +x.forecast || 0;
        a.boxes += typeof planBoxes(x) === "number" ? planBoxes(x) : 0;
        a.orders += +x.orders || 0;
        a.stock += +x.stock || 0;
        a.safety += +product(x.productId).safety || 0;
        a.need += planNeed(x);
        return a;
      },
      { forecast: 0, boxes: 0, orders: 0, stock: 0, safety: 0, need: 0 },
    ),
    body = rows
      .map((x) => {
        let p = product(x.productId);
        return `<tr><td>${xml(p.sku)}</td><td>${xml(p.name)}</td><td>${xml(p.unit)}</td><td class="num">${fmt(x.forecast)}</td><td class="num strong">${xml(typeof planBoxes(x) === "number" ? fmt(planBoxes(x)) : planBoxes(x))}</td><td class="num">${fmt(x.orders)}</td><td class="num">${fmt(x.stock)}</td><td class="num">${fmt(p.safety)}</td><td class="num strong">${fmt(planNeed(x))}</td></tr>`;
      })
      .join("");
  w.document.write(
    `<!doctype html><html><head><meta charset="utf-8"><title>Planejamento ${xml(label)}</title><style>@page{size:A4 landscape;margin:10mm}body{font-family:Arial,sans-serif;color:#111;margin:0}.head{display:flex;justify-content:space-between;align-items:center;border-bottom:4px solid #D9AE16;padding-bottom:10px;margin-bottom:14px}.head img{width:180px;max-height:70px;object-fit:contain;background:#050505;padding:8px}.head h1{font-size:22px;margin:0}.head p{margin:5px 0 0;color:#555}.summary{display:flex;gap:24px;margin:10px 0 15px;font-size:11px}table{width:100%;border-collapse:collapse;font-size:9px}th{background:#050505;color:#F0CB3D;padding:7px;text-align:left}td{padding:6px;border:1px solid #bbb}.num{text-align:right}.strong{font-weight:bold;background:#FFF8D9}tfoot td{font-weight:bold;background:#F0F0F0}.sign{display:flex;justify-content:space-around;margin-top:35px}.sign div{width:28%;border-top:1px solid #333;text-align:center;padding-top:5px;font-size:10px}.footer{margin-top:10px;font-size:9px;color:#666;text-align:right}</style></head><body><div class="head"><img src="${logo}"><div><h1>PLANEJAMENTO MENSAL DE PRODUÇÃO</h1><p>${xml(label.toUpperCase())}</p></div></div><div class="summary"><b>SKUs: ${rows.length}</b><b>Previsão: ${fmt(totals.forecast)} un</b><b>Caixas de 12 un: ${fmt(totals.boxes)}</b><b>Necessidade líquida: ${fmt(totals.need)}</b><b>Emissão: ${new Date().toLocaleString("pt-BR")}</b></div><table><thead><tr><th>SKU</th><th>Produto</th><th>Unidade</th><th>Previsão (un)</th><th>Caixas (12 un)</th><th>Pedidos</th><th>Estoque inicial</th><th>Segurança</th><th>Necessidade líquida</th></tr></thead><tbody>${body || '<tr><td colspan="9">Nenhum planejamento no período.</td></tr>'}</tbody><tfoot><tr><td colspan="3">TOTAIS</td><td class="num">${fmt(totals.forecast)}</td><td class="num">${fmt(totals.boxes)}</td><td class="num">${fmt(totals.orders)}</td><td class="num">${fmt(totals.stock)}</td><td class="num">${fmt(totals.safety)}</td><td class="num">${fmt(totals.need)}</td></tr></tfoot></table><div class="sign"><div>Elaborado por</div><div>PCP</div><div>Aprovação da Produção</div></div><div class="footer">MAXBEM PCP • Conversão: 1 caixa = 12 unidades • Planejamento mensal controlado pelo banco local</div></body></html>`,
  );
  w.document.close();
  w.onload = () => {
    w.opener = null;
    setTimeout(() => w.print(), 300);
  };
}
function orderForm(id) {
  let x = state.orders.find((x) => x.id == id),
    code =
      "OP-" +
      new Date().toISOString().slice(0, 10).replaceAll("-", "") +
      "-" +
      String(state.orders.length + 1).padStart(3, "0"),
    values = x || { code, date: new Date().toISOString().slice(0, 10) };
  openForm(
    id ? "Editar ordem de produção" : "Ordem de produção",
    [
      ["code", "Código OP"],
      ["productId", "Produto", "select", prodOpts()],
      ["qty", "Quantidade", "number"],
      ["date", "Data programada", "date"],
      [
        "line",
        "Linha",
        "select",
        [
          ["Linha 1", "Linha 1"],
          ["Linha 2", "Linha 2"],
        ],
      ],
      [
        "shift",
        "Turno",
        "select",
        [
          ["Comercial", "Comercial"],
          ["1º turno", "1º turno"],
          ["2º turno", "2º turno"],
        ],
      ],
      [
        "priority",
        "Prioridade",
        "select",
        [
          ["Normal", "Normal"],
          ["Alta", "Alta"],
          ["Urgente", "Urgente"],
        ],
      ],
      [
        "status",
        "Status",
        "select",
        [
          ["Planejada", "Planejada"],
          ["Liberada", "Liberada"],
          ["Em produção", "Em produção"],
          ["Concluída", "Concluída"],
        ],
      ],
    ],
    (v) => {
      if (id) Object.assign(x, v);
      else state.orders.push({ ...v, id: newId() });
      return save();
    },
    values,
  );
}
function logForm(id) {
  if (!state.orders.length) return alert("Cadastre uma ordem primeiro.");
  let x = state.logs.find((x) => x.id == id),
    values = x || {
      date: new Date().toISOString().slice(0, 10),
      scrap: 0,
      stop: 0,
    };
  openForm(
    id ? "Editar apontamento" : "Apontamento",
    [
      ["orderId", "Ordem", "select", orderOpts()],
      ["date", "Data", "date"],
      ["good", "Produção boa", "number"],
      ["scrap", "Perdas", "number"],
      ["ph", "Horas previstas", "number"],
      ["ah", "Horas reais", "number"],
      ["stop", "Parada (min)", "number"],
      ["reason", "Motivo"],
    ],
    (v) => {
      if (id) Object.assign(x, v);
      else state.logs.push({ ...v, id: newId() });
      return save();
    },
    values,
  );
}
function stockItemForm(id) {
  let x = state.stock.find((x) => x.id == id),
    values = x || {};
  openForm(
    id ? "Editar item de estoque" : "Item de estoque",
    [
      ["code", "Código"],
      ["name", "Descrição"],
      ["unit", "Unidade"],
      ["minimum", "Estoque mínimo", "number"],
    ],
    (v) => {
      if (id) Object.assign(x, v);
      else state.stock.push({ ...v, balance: 0, id: newId() });
      return save();
    },
    values,
  );
}
function moveForm() {
  openForm(
    "Movimentação",
    [
      [
        "itemId",
        "Item",
        "select",
        state.stock.map((x) => [x.id, `${x.code} — ${x.name}`]),
      ],
      [
        "type",
        "Tipo",
        "select",
        [
          ["Entrada", "Entrada"],
          ["Saída", "Saída"],
          ["Ajuste +", "Ajuste +"],
          ["Ajuste -", "Ajuste -"],
        ],
      ],
      ["qty", "Quantidade", "number"],
      ["reference", "Referência"],
    ],
    (v) => {
      let i = state.stock.find((x) => x.id == v.itemId),
        q = +v.qty;
      if (!i || !Number.isFinite(q) || q <= 0)
        throw new Error("Selecione um item e uma quantidade positiva.");
      let balance =
        +i.balance + (["Entrada", "Ajuste +"].includes(v.type) ? q : -q);
      if (balance < 0)
        throw new Error("Saldo insuficiente: a saída não foi registrada.");
      i.balance = balance;
      state.moves.push({ ...v, id: newId(), date: new Date().toISOString() });
      return save();
    },
  );
}
function download(name, text, type = "application/json") {
  const a = document.createElement("a"),
    url = URL.createObjectURL(new Blob([text], { type }));
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function backup() {
  download(
    `maxbem_pcp_backup_${new Date().toISOString().slice(0, 10)}.json`,
    JSON.stringify(state, null, 2),
  );
}
async function restore(input) {
  const file = input.files[0];
  if (!file) return;
  try {
    if (file.size > MAX_FILE)
      throw new Error("O backup excede o limite de 5 MiB.");
    const candidate = PCPData.validate(JSON.parse(await file.text()));
    if (
      !confirm(
        "Substituir o banco pelo backup validado? A versão anterior ficará no arquivo .bak. Exporte um backup antes de continuar.",
      )
    )
      return;
    state = candidate;
    await save();
    alert("Backup restaurado e gravação confirmada.");
  } catch (error) {
    alert("Não foi possível restaurar: " + error.message);
  } finally {
    input.value = "";
  }
}
function csvCell(value) {
  let text = String(value ?? "");
  if (/^[\s]*[=+@-]/.test(text)) text = "'" + text;
  return '"' + text.replaceAll('"', '""') + '"';
}
function csv(k) {
  if (!["orders", "logs"].includes(k)) return;
  const rows = state[k];
  if (!rows.length) return alert("Sem registros.");
  const headers = Object.keys(rows[0]);
  const text = [
    headers.map(csvCell).join(";"),
    ...rows.map((row) => headers.map((key) => csvCell(row[key])).join(";")),
  ].join("\r\n");
  download(`${k}.csv`, "\ufeff" + text, "text/csv;charset=utf-8");
}
function xml(v) {
  return String(v ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}
function exportExcel() {
  let sheets = [
    [
      "Produtos",
      ["SKU", "Produto", "Unidade", "Capacidade/h", "Estoque segurança"],
      state.products.map((x) => [
        x.sku,
        x.name,
        x.unit,
        +x.capacity || 0,
        +x.safety || 0,
      ]),
    ],
    [
      "Planejamento",
      [
        "Mês",
        "SKU",
        "Produto",
        "Previsão (un)",
        "Caixas (12 un)",
        "Pedidos firmes",
        "Estoque inicial",
        "Necessidade",
      ],
      state.plans.map((x) => {
        let p = product(x.productId),
          n = planNeed(x);
        return [
          x.month,
          p.sku,
          p.name,
          +x.forecast || 0,
          planBoxes(x),
          +x.orders || 0,
          +x.stock || 0,
          n,
        ];
      }),
    ],
    [
      "Programação diária",
      [
        "Data",
        "Dia",
        "SKU",
        "Produto",
        "Quantidade",
        "Linha",
        "Turno",
        "Status",
        "Observações",
      ],
      state.schedules.map((x) => [
        x.date,
        weekday(x.date),
        product(x.productId).sku,
        product(x.productId).name,
        +x.qty || 0,
        x.line,
        x.shift,
        x.status,
        x.notes || "",
      ]),
    ],
    [
      "Ordens",
      [
        "OP",
        "Data",
        "Produto",
        "Quantidade",
        "Linha",
        "Turno",
        "Prioridade",
        "Status",
      ],
      state.orders.map((x) => [
        x.code,
        x.date,
        product(x.productId).name,
        +x.qty || 0,
        x.line,
        x.shift,
        x.priority,
        x.status,
      ]),
    ],
    [
      "Apontamentos",
      [
        "Data",
        "OP",
        "Produção boa",
        "Perdas",
        "Horas previstas",
        "Horas reais",
        "Parada min",
        "Motivo",
      ],
      state.logs.map((x) => [
        x.date,
        state.orders.find((o) => o.id == x.orderId)?.code || "-",
        +x.good || 0,
        +x.scrap || 0,
        +x.ph || 0,
        +x.ah || 0,
        +x.stop || 0,
        x.reason || "",
      ]),
    ],
    [
      "Estoque",
      ["Código", "Item", "Unidade", "Saldo", "Mínimo", "Situação"],
      state.stock.map((x) => [
        x.code,
        x.name,
        x.unit,
        +x.balance || 0,
        +x.minimum || 0,
        +x.balance < +x.minimum ? "CRÍTICO" : "OK",
      ]),
    ],
    [
      "Movimentações",
      ["Data", "Item", "Tipo", "Quantidade", "Referência"],
      state.moves.map((x) => [
        x.date,
        state.stock.find((i) => i.id == x.itemId)?.name || "-",
        x.type,
        +x.qty || 0,
        x.reference || "",
      ]),
    ],
  ];
  let cell = (v, header = false) =>
      `<Cell${header ? ' ss:StyleID="Header"' : ""}><Data ss:Type="${typeof v === "number" ? "Number" : "String"}">${xml(v)}</Data></Cell>`,
    book = `<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Styles><Style ss:ID="Default"><Alignment ss:Vertical="Center"/><Font ss:FontName="Arial" ss:Size="10"/></Style><Style ss:ID="Header"><Font ss:FontName="Arial" ss:Size="10" ss:Bold="1" ss:Color="#F0CB3D"/><Interior ss:Color="#050505" ss:Pattern="Solid"/></Style></Styles>${sheets.map(([name, h, rows]) => `<Worksheet ss:Name="${xml(name)}"><Table><Row>${h.map((v) => cell(v, true)).join("")}</Row>${rows.map((r) => `<Row>${r.map((v) => cell(v)).join("")}</Row>`).join("")}</Table></Worksheet>`).join("")}</Workbook>`;
  download(
    `MAXBEM_PCP_${new Date().toISOString().slice(0, 10)}.xls`,
    "\ufeff" + book,
    "application/vnd.ms-excel",
  );
}
async function resetAll() {
  if (
    confirm(
      "Substituir todos os dados pelos exemplos? Exporte um backup antes. A versão anterior ficará no arquivo .bak.",
    )
  ) {
    state = structuredClone(seed);
    await save();
  }
}
function canvasCtx(id) {
  let c = $("#" + id);
  if (!c) return null;
  let r = devicePixelRatio || 1,
    w = Math.max(c.clientWidth, 240),
    h = Math.max(c.clientHeight, 180);
  c.width = w * r;
  c.height = h * r;
  let x = c.getContext("2d");
  x.scale(r, r);
  x.lineCap = "round";
  x.lineJoin = "round";
  return { x, w, h };
}
function drawPlan() {
  let q = canvasCtx("planChart");
  if (!q) return;
  let { x, w, h } = q,
    d = metrics(),
    data = [
      ["Planejado", d.planned, "#D9AE16"],
      ["Realizado", d.produced, "#161616"],
    ],
    max = Math.max(d.planned, d.produced, 1),
    base = h - 38,
    bw = Math.min(88, w / 5),
    gap = Math.min(90, w / 5),
    start = w / 2 - bw - gap / 2;
  x.strokeStyle = "#E6DFC9";
  x.lineWidth = 1;
  for (let i = 0; i < 4; i++) {
    let y = 18 + ((base - 25) * i) / 3;
    x.beginPath();
    x.moveTo(30, y);
    x.lineTo(w - 20, y);
    x.stroke();
  }
  data.forEach((b, i) => {
    let bh = ((base - 35) * b[1]) / max,
      bx = start + i * (bw + gap);
    x.fillStyle = b[2];
    x.beginPath();
    x.roundRect(bx, base - bh, bw, bh, 8);
    x.fill();
    x.fillStyle = "#151515";
    x.font = "700 12px -apple-system";
    x.textAlign = "center";
    x.fillText(fmt(b[1]), bx + bw / 2, base - bh - 8);
    x.fillStyle = "#646A75";
    x.font = "11px -apple-system";
    x.fillText(b[0], bx + bw / 2, h - 15);
  });
}
function drawGauge(id, value) {
  let q = canvasCtx(id);
  if (!q) return;
  let { x, w, h } = q,
    v = Math.max(0, Math.min(Number(value) || 0, 100)),
    cx = w / 2,
    cy = h * 0.62,
    r = Math.min(w, h) * 0.33;
  x.lineWidth = 19;
  x.strokeStyle = "#EEE8D6";
  x.beginPath();
  x.arc(cx, cy, r, Math.PI * 0.78, Math.PI * 2.22);
  x.stroke();
  x.strokeStyle = v >= 95 ? "#1F8A50" : v >= 80 ? "#D9AE16" : "#B93838";
  x.beginPath();
  x.arc(cx, cy, r, Math.PI * 0.78, Math.PI * 0.78 + (Math.PI * 1.44 * v) / 100);
  x.stroke();
  x.fillStyle = "#646A75";
  x.font = "10px -apple-system";
  x.textAlign = "center";
  x.fillText("0", cx - r - 5, cy + r * 0.75);
  x.fillText("100", cx + r + 8, cy + r * 0.75);
}
function drawTrend() {
  let q = canvasCtx("trendChart");
  if (!q) return;
  let { x, w, h } = q,
    group = {};
  state.logs.forEach((l) => {
    let k = l.date || "Sem data";
    group[k] ??= { good: 0, scrap: 0 };
    group[k].good += Number(l.good) || 0;
    group[k].scrap += Number(l.scrap) || 0;
  });
  let rows = Object.entries(group)
    .sort((a, b) => a[0].localeCompare(b[0]))
    .slice(-8);
  if (!rows.length) {
    x.fillStyle = "#646A75";
    x.font = "13px -apple-system";
    x.textAlign = "center";
    x.fillText(
      "Registre apontamentos para visualizar a tendência",
      w / 2,
      h / 2,
    );
    return;
  }
  let max = Math.max(...rows.flatMap((r) => [r[1].good, r[1].scrap]), 1),
    left = 42,
    right = 18,
    top = 18,
    bottom = 38,
    pw = w - left - right,
    ph = h - top - bottom;
  x.strokeStyle = "#E6DFC9";
  x.lineWidth = 1;
  for (let i = 0; i < 4; i++) {
    let y = top + (ph * i) / 3;
    x.beginPath();
    x.moveTo(left, y);
    x.lineTo(w - right, y);
    x.stroke();
  }
  function line(key, color) {
    x.strokeStyle = color;
    x.lineWidth = 3;
    x.beginPath();
    rows.forEach((r, i) => {
      let px =
          left + (rows.length === 1 ? pw / 2 : (pw * i) / (rows.length - 1)),
        py = top + ph - (r[1][key] / max) * ph;
      i ? x.lineTo(px, py) : x.moveTo(px, py);
    });
    x.stroke();
    rows.forEach((r, i) => {
      let px =
          left + (rows.length === 1 ? pw / 2 : (pw * i) / (rows.length - 1)),
        py = top + ph - (r[1][key] / max) * ph;
      x.fillStyle = color;
      x.beginPath();
      x.arc(px, py, 4, 0, Math.PI * 2);
      x.fill();
    });
  }
  line("good", "#D9AE16");
  line("scrap", "#B93838");
  x.fillStyle = "#646A75";
  x.font = "10px -apple-system";
  x.textAlign = "center";
  rows.forEach((r, i) => {
    let px = left + (rows.length === 1 ? pw / 2 : (pw * i) / (rows.length - 1));
    x.fillText(r[0].slice(5), px, h - 14);
  });
}
function drawDashboardCharts() {
  let d = metrics();
  drawPlan();
  drawGauge("adherenceGauge", d.adh);
  drawGauge("efficiencyGauge", d.eff);
  drawTrend();
}
const actions = {
  productForm,
  planForm,
  distributeForm,
  scheduleForm,
  planningPrintForm,
  printSchedule,
  orderForm,
  logForm,
  stockItemForm,
  moveForm,
  exportExcel,
  backup,
  resetAll,
  csv: (_, button) => csv(button.dataset.key),
  cancel: () => $("#dlg").close(),
  exportRecovery: () =>
    recovery &&
    download(
      "maxbem_alteracoes_pendentes.json",
      JSON.stringify(recovery, null, 2),
    ),
  reload: () => {
    if (
      !recovery ||
      confirm(
        "Confirme que exportou as alterações pendentes antes de recarregar.",
      )
    )
      location.reload();
  },
};
document.addEventListener("click", async (event) => {
  const button = event.target.closest("[data-action]");
  if (!button) return;
  const action = actions[button.dataset.action];
  if (!action) return;
  event.preventDefault();
  if (saving) return;
  if (
    recovery &&
    ![
      "cancel",
      "exportRecovery",
      "reload",
      "backup",
      "exportExcel",
      "csv",
    ].includes(button.dataset.action)
  ) {
    alert(
      "Exporte as alterações pendentes e recarregue o banco antes de editar novamente.",
    );
    return;
  }
  const id = button.dataset.id ? Number(button.dataset.id) : undefined;
  if (id !== undefined && (!Number.isSafeInteger(id) || id <= 0)) return;
  try {
    await action(id, button);
  } catch (error) {
    alert(error.message);
  }
});
document.addEventListener("change", (event) => {
  if (event.target.dataset.change === "month")
    changeScheduleMonth(event.target.value);
  if (event.target.dataset.change === "restore" && !saving && !recovery)
    restore(event.target);
});
window.addEventListener("beforeunload", (event) => {
  if (saving || recovery) {
    event.preventDefault();
    event.returnValue = "";
  }
});
init();
