Option Explicit
Dim shell, desktop, startMenu, target, icon, shortcut
Set shell = CreateObject("WScript.Shell")
desktop = shell.SpecialFolders("Desktop")
startMenu = shell.SpecialFolders("Programs")
target = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\MAXBEM_PCP\Iniciar_MAXBEM_PCP.cmd"
icon = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\MAXBEM_PCP\maxbem_m.ico"

Set shortcut = shell.CreateShortcut(desktop & "\MAXBEM PCP.lnk")
shortcut.TargetPath = target
shortcut.WorkingDirectory = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\MAXBEM_PCP"
shortcut.IconLocation = icon & ",0"
shortcut.Description = "MAXBEM PCP - Planejamento, Programacao e Controle da Producao"
shortcut.Save

Set shortcut = shell.CreateShortcut(startMenu & "\MAXBEM PCP.lnk")
shortcut.TargetPath = target
shortcut.WorkingDirectory = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\MAXBEM_PCP"
shortcut.IconLocation = icon & ",0"
shortcut.Description = "MAXBEM PCP - Planejamento, Programacao e Controle da Producao"
shortcut.Save

WScript.Echo "Atalhos criados com sucesso."

