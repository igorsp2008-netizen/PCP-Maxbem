﻿$ErrorActionPreference='Stop'
$Url='http://127.0.0.1:48721'
function Port-InUse {
    $Client=New-Object Net.Sockets.TcpClient
    try {
        $Task=$Client.ConnectAsync('127.0.0.1',48721)
        return $Task.Wait(300) -and $Client.Connected
    } catch { return $false } finally { $Client.Dispose() }
}
function Check-Server {
    try {
        $Health=Invoke-RestMethod -Uri "$Url/api/health" -TimeoutSec 2
        return $Health.app -ceq 'MAXBEM-PCP' -and $Health.version -ceq '1.7.0' -and $Health.protocol -eq 2
    } catch { return $false }
}
try {
    if (Port-InUse) {
        if (-not (Check-Server)) { throw 'A porta 48721 esta ocupada, o servidor esta desatualizado ou o banco esta invalido. Feche o servidor antigo e consulte LEIA-ME.txt. Nenhum banco foi substituido.' }
    } else {
        $Server=Join-Path $PSScriptRoot 'Servidor_MAXBEM_PCP.ps1'
        $Process=Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','RemoteSigned','-File',('"'+$Server+'"')) -WindowStyle Minimized -PassThru
        $Ready=$false
        for ($Attempt=0;$Attempt -lt 15;$Attempt++) {
            if ($Process.HasExited) { throw 'O servidor encerrou antes de ficar pronto. Consulte data\server.log.' }
            if (Check-Server) { $Ready=$true; break }
            Start-Sleep -Milliseconds 200
        }
        if (-not $Ready) {
            if (-not $Process.HasExited) { Stop-Process -Id $Process.Id }
            throw 'O banco local nao ficou pronto. Preserve os dados e consulte data\server.log.'
        }
    }
    $Candidates=@()
    foreach ($Directory in @(${env:ProgramFiles(x86)},$env:ProgramFiles)) {
        if ($Directory) { $Candidates+=Join-Path $Directory 'Microsoft\Edge\Application\msedge.exe' }
    }
    $Edge=$Candidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    if ($Edge) { Start-Process -FilePath $Edge -ArgumentList @("--app=$Url/",'--start-maximized') }
    else { Start-Process "$Url/" }
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
