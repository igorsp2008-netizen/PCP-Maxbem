"use strict";
(function (root) {
  const boxes = (units) => Math.floor(Number(units) / 12);
  function need(plan, product) {
    const forecast =
      product.unit === "caixas" ? boxes(plan.forecast) : Number(plan.forecast);
    return Math.max(
      0,
      forecast +
        Number(plan.orders) +
        Number(product.safety) -
        Number(plan.stock),
    );
  }
  function distribute(total, count, unit) {
    if (
      !Number.isFinite(total) ||
      total < 0 ||
      !Number.isInteger(count) ||
      count < 1 ||
      count > 31
    )
      throw new Error("Distribuição inválida.");
    // Whole boxes/units stay whole. Fractional historical values retain their total.
    if (unit !== "kg" && Number.isInteger(total)) {
      const base = Math.floor(total / count),
        remainder = total % count;
      return Array.from(
        { length: count },
        (_, i) => base + (i < remainder ? 1 : 0),
      );
    }
    const base = Math.floor((total * 1000) / count) / 1000;
    return Array.from({ length: count }, (_, i) =>
      i === count - 1 ? Number((total - base * (count - 1)).toFixed(6)) : base,
    );
  }
  const api = { boxes, need, distribute };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.PCPCalc = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
