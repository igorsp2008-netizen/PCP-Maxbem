"use strict";
// Shared by the browser and the regression tests. No dependencies or network access.
(function (root) {
  const text = (max = 160, optional = false) => ({
    type: "text",
    max,
    optional,
  });
  const num = (min = 0, max = 1e12) => ({ type: "number", min, max });
  const id = {
    type: "number",
    min: 1,
    max: Number.MAX_SAFE_INTEGER,
    integer: true,
  };
  const ref = { ...id };
  const choice = (...values) => ({ type: "enum", values });
  const line = choice("Linha 1", "Linha 2");
  const shift = choice("Comercial", "1º turno", "2º turno");
  const date = { type: "date" };
  const definitions = {
    products: {
      id,
      sku: text(80),
      name: text(),
      unit: choice("caixas", "unidades", "kg"),
      capacity: num(0.000001),
      safety: num(),
    },
    plans: {
      id,
      productId: ref,
      month: { type: "month" },
      forecast: num(),
      orders: num(),
      stock: num(),
    },
    schedules: {
      id,
      planId: { ...ref, nullable: true },
      productId: ref,
      date,
      qty: num(),
      line,
      shift,
      status: choice(
        "Programada",
        "Liberada",
        "Em produção",
        "Concluída",
        "Cancelada",
      ),
      notes: text(500, true),
    },
    orders: {
      id,
      code: text(80),
      productId: ref,
      qty: num(0.000001),
      date,
      line,
      shift,
      priority: choice("Normal", "Alta", "Urgente"),
      status: choice(
        "Planejada",
        "Liberada",
        "Em produção",
        "Concluída",
        "Cancelada",
      ),
    },
    logs: {
      id,
      orderId: ref,
      date,
      good: num(),
      scrap: num(),
      ph: num(),
      ah: num(),
      stop: num(),
      reason: text(500, true),
    },
    stock: {
      id,
      code: text(80),
      name: text(),
      unit: text(30),
      minimum: num(),
      balance: num(-1e12),
    },
    moves: {
      id,
      itemId: ref,
      type: choice("Entrada", "Saída", "Ajuste +", "Ajuste -"),
      qty: num(0.000001),
      reference: text(500, true),
      date: { type: "timestamp" },
    },
  };
  function fail(message) {
    throw new Error("Dados inválidos: " + message);
  }
  function plain(value) {
    return (
      value !== null &&
      typeof value === "object" &&
      !Array.isArray(value) &&
      Object.getPrototypeOf(value) === Object.prototype
    );
  }
  function validDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const d = new Date(value + "T12:00:00Z");
    return (
      Number.isFinite(d.getTime()) &&
      d.toISOString().slice(0, 10) === value &&
      +value.slice(0, 4) >= 1900
    );
  }
  function field(value, rule, path) {
    if (value == null && rule.nullable) return null;
    if (value == null && rule.optional) return "";
    if (rule.type === "number") {
      if (
        typeof value !== "number" &&
        !(typeof value === "string" && /^-?\d+(\.\d+)?$/.test(value))
      )
        fail(path);
      const n = Number(value);
      if (
        !Number.isFinite(n) ||
        n < rule.min ||
        n > rule.max ||
        (rule.integer && !Number.isSafeInteger(n))
      )
        fail(path);
      return n;
    }
    if (typeof value !== "string") fail(path);
    if (rule.type === "text") {
      value = value.trim();
      if (
        (!rule.optional && !value) ||
        value.length > rule.max ||
        /[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(value)
      )
        fail(path);
    } else if (rule.type === "enum" && !rule.values.includes(value)) fail(path);
    else if (rule.type === "date" && !validDate(value)) fail(path);
    else if (rule.type === "month" && !validDate(value + "-01")) fail(path);
    else if (
      rule.type === "timestamp" &&
      (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value) ||
        !validDate(value.slice(0, 10)) ||
        !Number.isFinite(Date.parse(value)))
    )
      fail(path);
    return value;
  }
  function validate(input) {
    if (!plain(input)) fail("o backup deve ser um objeto");
    for (const k of Object.keys(input))
      if (!Object.hasOwn(definitions, k)) fail("campo desconhecido: " + k);
    const output = {};
    let count = 0;
    for (const [name, fields] of Object.entries(definitions)) {
      const rows =
        input[name] === undefined && name === "schedules" ? [] : input[name];
      if (
        !Array.isArray(rows) ||
        rows.length > 10000 ||
        (count += rows.length) > 30000
      )
        fail(name + ": limite de registros ou lista ausente");
      const ids = new Set();
      const codes = new Set();
      output[name] = rows.map((row, i) => {
        if (!plain(row)) fail(name + "[" + i + "]");
        for (const k of Object.keys(row))
          if (!Object.hasOwn(fields, k))
            fail(name + ": campo desconhecido " + k);
        const clean = {};
        for (const [key, rule] of Object.entries(fields))
          clean[key] = field(row[key], rule, name + "." + key);
        if (ids.has(clean.id)) fail(name + ": ID duplicado");
        ids.add(clean.id);
        if (["products", "orders", "stock"].includes(name)) {
          const code = (clean.sku || clean.code).toLocaleUpperCase("pt-BR");
          if (codes.has(code)) fail(name + ": código duplicado");
          codes.add(code);
        }
        return clean;
      });
    }
    const ids = Object.fromEntries(
      Object.entries(output).map(([k, rows]) => [
        k,
        new Set(rows.map((r) => r.id)),
      ]),
    );
    for (const name of ["plans", "schedules", "orders"])
      for (const row of output[name])
        if (!ids.products.has(row.productId))
          fail(name + ": produto inexistente");
    for (const row of output.schedules)
      if (row.planId !== null && !ids.plans.has(row.planId))
        fail("programação: plano inexistente");
    for (const row of output.logs)
      if (!ids.orders.has(row.orderId)) fail("apontamento: ordem inexistente");
    for (const row of output.moves)
      if (!ids.stock.has(row.itemId)) fail("movimentação: item inexistente");
    return output;
  }
  const api = { validate, definitions, validDate };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.PCPData = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
