﻿$ErrorActionPreference='Stop'
$InstallLock=$null
try {
    $Client=New-Object Net.Sockets.TcpClient
    $Active=$false
    try { $Task=$Client.ConnectAsync('127.0.0.1',48721); $Active=$Task.Wait(300) -and $Client.Connected } catch {} finally { $Client.Dispose() }
    if ($Active) { throw 'Feche a janela do servidor MAXBEM PCP antes de atualizar. Se nao conseguir localiza-la, reinicie o Windows e instale antes de abrir o app.' }
    $Dest=Join-Path $env:LOCALAPPDATA 'MAXBEM_PCP'
    $DataDir=Join-Path $Dest 'data'
    $Files=@('index.html','app.js','business.js','schema.js','schema.json','styles.css','maxbem_logo.png','maxbem_m.ico','Criar_Atalho.vbs','Iniciar_MAXBEM_PCP.cmd','Iniciar_MAXBEM_PCP.ps1','Servidor_MAXBEM_PCP.ps1')
    foreach ($Name in $Files) { if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot "app\$Name"))) { throw "Pacote incompleto: $Name" } }
    [IO.Directory]::CreateDirectory($DataDir) | Out-Null
    $InstallLock=[IO.File]::Open((Join-Path $DataDir '.server.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $Database=Join-Path $DataDir 'maxbem_pcp_database.json'
    if (Test-Path -LiteralPath $Database) {
        $Copy=Join-Path $DataDir ("maxbem_pcp_pre_update_"+(Get-Date -Format 'yyyyMMdd_HHmmss_fff')+'.json')
        Copy-Item -LiteralPath $Database -Destination $Copy -ErrorAction Stop
        Write-Host 'Copia do banco anterior preservada antes da atualizacao.'
    }
    foreach ($Name in $Files) { Copy-Item -LiteralPath (Join-Path $PSScriptRoot "app\$Name") -Destination (Join-Path $Dest $Name) -Force }
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'LEIA-ME.txt') -Destination (Join-Path $Dest 'LEIA-ME.txt') -Force
    & cscript.exe //nologo (Join-Path $Dest 'Criar_Atalho.vbs')
    if ($LASTEXITCODE -ne 0) { throw 'Arquivos instalados, mas nao foi possivel criar os atalhos. Execute Iniciar_MAXBEM_PCP.cmd na pasta de instalacao.' }
    Write-Host 'MAXBEM PCP 1.7.0 instalado no perfil do usuario, sem privilegios administrativos.'
    $InstallLock.Dispose(); $InstallLock=$null
    & (Join-Path $Dest 'Iniciar_MAXBEM_PCP.ps1')
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
finally { if ($null -ne $InstallLock) { $InstallLock.Dispose() } }
