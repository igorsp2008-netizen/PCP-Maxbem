@echo off
setlocal
title Instalador MAXBEM PCP 1.7.0
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0Instalar_MAXBEM_PCP.ps1"
if errorlevel 1 (
  echo Instalacao interrompida. Nao execute como administrador para contornar o erro.
  pause
  exit /b 1
)
exit /b 0
