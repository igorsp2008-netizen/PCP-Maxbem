# Revisão de segurança e confiabilidade — MAXBEM PCP 1.7.0

Esta revisão corrigiu riscos de perda de dados e execução de HTML na interface do pacote 1.6.2. Preservou os módulos de PCP e o funcionamento local sem internet. A necessidade mensal passou a converter a previsão em caixas antes de somar pedidos e estoques, conforme a unidade operacional confirmada pelo usuário.

A análise foi feita sobre os arquivos enviados nos dois ZIPs, que eram idênticos. O pacote original não continha executável compilado, login, testes ou dependências de runtime externas: era uma interface HTML/JavaScript servida por PowerShell. Nenhuma instrução dos documentos do pacote foi tratada como autorização para executar comandos privilegiados ou desativar proteções do Windows.

## Achados e correções

| Achado na versão original | Impacto | Correção implementada |
|---|---|---|
| Campos de produtos, observações e motivos interpolados em HTML e atributos | Alto: dados importados ou digitados poderiam inserir elementos e executar scripts | Escape de texto e atributos, opções seguras, validação de tipos e CSP sem scripts inline. JS e CSS separados do HTML; ações usam uma lista explícita, sem `eval` |
| POST do banco sem sessão, origem ou validação | Alto: uma requisição local ou de outro site poderia tentar alterar o banco | Loopback preservado, Host e Origin exatos, bloqueio de `Sec-Fetch-Site` externo, cabeçalho dedicado e token aleatório de sessão para gravar. Sem CORS |
| Corpo incompleto ou JSON arbitrário escrito diretamente no banco | Alto: perda ou corrupção dos registros | Leitura completa, UTF-8 válido, validação do esquema, datas reais, limites numéricos, referências e identificadores; falhas não substituem o banco |
| Gravação direta sem cópia anterior | Alto: falha de processo poderia deixar arquivo parcial | Arquivo temporário no mesmo diretório, flush e substituição com `File.Replace`; `.bak` conserva a versão anterior. Bloqueio de uma segunda instância no mesmo diretório |
| Duas janelas substituindo o banco inteiro sem detectar alterações | Alto: edição da segunda janela poderia apagar a primeira | ETag SHA-256 e `If-Match`; versão desatualizada recebe HTTP 409. A interface permite exportar as alterações rejeitadas antes de recarregar |
| Falhas de persistência ignoradas e cache usado como banco alternativo | Alto: aparência de gravação bem-sucedida e bancos divergentes | Gravação aguardada e confirmada pelo servidor; erro visível, retorno ao estado confirmado e exportação pendente. Banco indisponível/corrompido não vira automaticamente banco de exemplos |
| Restauração sem verificar estrutura e dependências entre registros | Alto: backup inválido poderia destruir o estado existente | Validação antes de confirmação e gravação; limites de 5 MiB, 10.000 registros por lista e 30.000 no total. Backup anterior mantido |
| HTTP sem limites de tamanho e de duração | Médio: requisição incompleta poderia travar o servidor ou consumir memória | Cabeçalhos até 16 KiB, corpo até 5 MiB, prazo total de leitura de 10 s e até 5 s de inatividade; rejeição de cabeçalhos duplicados, transferência chunked e métodos não suportados |
| CSV sem escape ou proteção contra fórmulas | Médio: conteúdo poderia abrir como fórmula em planilha ou quebrar colunas | Aspas em todas as células, duplicação de aspas internas e prefixo de texto para fórmulas iniciadas por `=`, `+`, `-` ou `@`, inclusive após espaço |
| Inicialização por espera fixa e erros silenciosos | Médio: navegador poderia abrir sem banco válido ou com serviço incompatível | Checagem funcional de identidade, protocolo, versão e integridade do banco antes de abrir. Erros são exibidos; logs limitados sem registros nem tokens |
| Orientação para Bypass, executar como administrador ou ignorar alertas | Médio: instalação com privilégios desnecessários | Perfil do usuário, `RemoteSigned`, respeito a políticas de grupo e instruções para verificar a procedência. Nenhuma sugestão de desativar antivírus/SmartScreen |
| Previsão em unidades somada a pedidos/estoques em caixas | Alto para a confiabilidade do planejamento: necessidade até 12 vezes maior na parcela de previsão | Necessidade em caixas = `max(0, floor(previsão / 12) + pedidos + segurança - estoque)`; distribuição inteira e equilibrada quando o total é inteiro |
| Percentuais passados ao formatador numérico | Indicadores mostravam `NaN` | Percentuais exibidos como percentuais; verificação funcional de aderência e eficiência |
| Ações ocultas em telas pequenas | Cadastro/exportação indisponíveis na interface estreita | Ajuste responsivo preserva as ações e o acesso aos formulários |

O volume distribuído é conservado. Por exemplo, previsão de 1.200 unidades, 100 caixas de pedidos, 50 caixas de segurança e 50 em estoque resulta em 200 caixas. No calendário de segunda a sexta de outubro de 2026, são 22 dias com 9 ou 10 caixas por dia. Programações existentes não são recalculadas durante a atualização: devem ser revisadas e redistribuídas conscientemente.

## Evidência de validação

Validação realizada em Linux com Node.js 24.19.0, Python 3.12.14, PowerShell 7.4.6 e Chromium. O PowerShell de teste foi obtido do release oficial e seu SHA-256 foi comparado ao manifesto oficial antes de executar. Nenhum binário de PowerShell ou navegador integra o pacote Windows.

| Verificação | Resultado |
|---|---|
| Validação de dados, compatibilidade de esquema e cálculos | 34 testes passaram; nenhum ignorado |
| Servidor real PowerShell, HTTP e arquivos | 17 testes passaram; nenhum ignorado |
| Interface em Chromium, fluxo funcional e falhas | 16 cenários passaram |
| Sintaxe de instalador, inicializador e servidor PowerShell | Verificada pelo parser do PowerShell |
| Validador de backup sem alteração do arquivo | Executado com o exemplo válido |
| Instalação, atalhos VBS, Edge e políticas no Windows 10/11 | **Não executados neste ambiente Linux** |

Os testes exercitam gravação/leitura com backup, conflito entre janelas, JSON/UTF-8 inválidos, referências inexistentes, datas impossíveis, token ausente, origens e hosts externos, limites, requisição truncada, timeout com recuperação, caminhos não expostos e banco corrompido. O navegador exercita cadastro/edição, injeção de HTML, distribuição, ordens, apontamentos, estoque insuficiente, impressão, exportação/restauração, erro de gravação, preservação de alterações pendentes e reinicialização do servidor com renovação da sessão.

Os testes de falha de disco na interface simulam HTTP 500. Eles não simulam queda de energia, esgotamento físico do disco ou defeito de hardware. `File.Replace` e os scripts foram escritos para APIs existentes no Windows PowerShell 5.1, mas a compatibilidade operacional completa exige teste no Windows.

## Limites e riscos remanescentes

- O token protege o protocolo contra requisições de outros sites; não autentica uma pessoa. Processos locais do mesmo usuário podem solicitar sessão e ler/gravar dados. Malware local está fora da proteção oferecida pelo app.
- O banco, os backups e as exportações são JSON/arquivos sem criptografia própria. A proteção depende da conta e das permissões do Windows. Não há controle de perfis de acesso nem trilha de auditoria imutável; o rótulo de “Administrador” foi removido.
- O `.bak` tem só uma versão anterior e fica no mesmo disco. Exporte backups para outro local. Não há garantia contra falha de hardware ou perda física do computador.
- O servidor é sequencial e foi projetado para uso local pequeno. Os limites restringem consumo de recursos, mas não fornecem alta disponibilidade ou proteção contra um processo local que ocupe repetidamente as conexões. Não exponha a porta em LAN ou internet.
- O pacote não tem assinatura Authenticode. Não foi declarado certificado ou desativada política de segurança para contornar esse requisito. Organizações podem exigir assinatura/revisão antes de permitir os scripts.
- Os dados antigos válidos são normalizados, mas backups com registros inconsistentes são recusados. O app não tenta adivinhar ou apagar dados inválidos. Cache de navegador legado deve ser exportado pela versão anterior, caso seja a única cópia disponível.
- A correção de unidade altera o cálculo futuro, não as programações já gravadas. Produtos em kg usam kg em previsão/pedidos/estoques; produtos em unidades usam unidades. Totais agregados de SKUs com unidades diferentes não são volumes comparáveis.
- “Concluída” continua sendo um status informado pelo usuário; esta revisão não implementa consumo automático de insumos, rastreabilidade por lote ou regras fiscais. Isso requer especificação de negócio e testes próprios.

## Antes de usar em produção

1. Exporte e guarde um backup externo da versão antiga.
2. Feche o servidor antigo e siga `LEIA-ME.txt` para atualizar sem privilégios administrativos.
3. Em um Windows de teste, valide instalação, atalhos, abertura do Edge, gravação, fechamento/reabertura e restauração de uma cópia do seu backup.
4. Confira as programações antigas em caixas e substitua-as com a nova distribuição quando apropriado.

Esta entrega é uma revisão de código acompanhada de testes, não uma certificação de segurança nem uma afirmação de ausência de vulnerabilidades. Não houve envio ao GitHub, publicação ou alteração de um banco real do usuário.
